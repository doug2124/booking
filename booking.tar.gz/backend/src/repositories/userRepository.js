const prisma = require("../../db");

const createUser = async (data) => {
    return await prisma.user.create({
      data
    });
  };
  
  const getUsers = async () => {
    return await prisma.user.findMany();
  };
  const getUserById=async(id)=>{
    return prisma.user.findUnique({
      where:{id:Number(id)}
    });
  };
  const deleteUserById=async(id)=>{
    return prisma.user.delete({
      where:{id:Number(id)}
    });
  };

  const updateUser=async(id,data)=>{
    return prisma.user.update({
      where:{id:Number(id)},
      data
    });
  };
  
  module.exports = {
    createUser,
    getUsers,
    getUserById,
    deleteUserById,
    updateUser
  };